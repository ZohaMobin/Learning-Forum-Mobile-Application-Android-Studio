package com.example.learning_forum;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import com.example.learning_forum.DbHelper;
import com.example.learning_forum.R;

import java.io.InputStreamReader;
import java.util.Vector;

public class Teacher_Update_Activity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        DbHelper db = new DbHelper(this);

        super.onCreate(savedInstanceState);
        setContentView(R.layout.teacher_update_page);
        Intent intent = getIntent();
        String email= getIntent().getStringExtra("TeacherEmailFromLogin");


        ImageButton edit;
        Spinner up_spin;
        EditText up_data;
        edit = (ImageButton) findViewById(R.id.imageButton3);
        up_spin= findViewById(R.id.spinner);

        up_data = findViewById(R.id.data1);
        edit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String datatxt = up_data.getText().toString();
                db.updateTeacher(datatxt,up_spin.getSelectedItem().toString(),email);

                // displaying a toast message that our course has been updated.
                Toast.makeText(Teacher_Update_Activity.this, "Course Updated", Toast.LENGTH_SHORT).show();
            }


        });
    }

}