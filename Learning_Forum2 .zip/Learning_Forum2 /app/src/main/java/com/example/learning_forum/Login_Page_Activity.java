package com.example.learning_forum;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Toast;

public class Login_Page_Activity extends AppCompatActivity {

    ImageButton buttonS,buttonL;
    @Override
    protected void onCreate(Bundle savedInstanceState) {

        DbHelper db = new DbHelper(this);

        super.onCreate(savedInstanceState);
        setContentView(R.layout.reg_login);
        Intent intent = getIntent();

        buttonS = (ImageButton) findViewById(R.id.btnInsert3);
        String value = getIntent().getStringExtra("UserType");



//        String emailTXT = email.getText().toString();
//        String passTXT = password.getText().toString();
//        System.out.println("From login page activity "+emailTXT+passTXT);

        buttonL = findViewById(R.id.btnInsert);
        EditText email = findViewById(R.id.email_reg);
        EditText password = findViewById(R.id.pass_reg);

        buttonL.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Boolean check;
                String emailTXT = email.getText().toString();
                String passTXT = password.getText().toString();

                if (value.equals("Student")) {
                    //System.out.println("From login page activity "+emailTXT+passTXT);
                    check = db.checkStudentLoginInfo(emailTXT,passTXT);
                    if(check) {
                        Toast.makeText(Login_Page_Activity.this, "Correct Data", Toast.LENGTH_SHORT).show();
                        Intent intent = new Intent(getApplicationContext(), Student_Dashboard_Activity.class);
                        intent.putExtra("StudentEmailFromLogin",emailTXT);
                        startActivity(intent);
                    }
                    else
                        Toast.makeText(Login_Page_Activity.this, "Invalid Data", Toast.LENGTH_SHORT).show();

                    //Intent intent = new Intent(getApplicationContext(), Student_Signup_Activity.class);
                    //startActivity(intent);
                }

                else if (value.equals("Teacher")) {
                    //System.out.println("From login page activity "+emailTXT+passTXT);
                    check = db.checkTeacherLoginInfo(emailTXT,passTXT);
                    if(check){
                        Toast.makeText(Login_Page_Activity.this, "Correct Data", Toast.LENGTH_SHORT).show();
                        Intent intent = new Intent(getApplicationContext(), Teacher_Dashboard_Activity.class);
                        intent.putExtra("TeacherEmailFromLogin",emailTXT);
                        startActivity(intent);

                        //Intent intent = new Intent(getApplicationContext(),.class);
                        startActivity(intent);
                    }

                    else
                        Toast.makeText(Login_Page_Activity.this, "Invalid Data", Toast.LENGTH_SHORT).show();

                    //Intent intent = new Intent(getApplicationContext(), Student_Signup_Activity.class);
                    //startActivity(intent);
                }

            }
        });

        buttonS.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {

                if (value.equals("Student")) {
                    //System.out.println(value);
                    Intent intent = new Intent(getApplicationContext(), Student_Signup_Activity.class);
                    startActivity(intent);
                }
                else if (value.equals("Teacher")){
                    Intent intent = new Intent(getApplicationContext(), Teacher_Signup_Activity.class);
                    startActivity(intent);
                }
            }
        });
    }
}