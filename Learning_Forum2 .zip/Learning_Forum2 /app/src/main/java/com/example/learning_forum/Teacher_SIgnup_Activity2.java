package com.example.learning_forum;

import static android.app.PendingIntent.getActivity;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Vector;

public class Teacher_SIgnup_Activity2 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        DbHelper db = new DbHelper(this);

        super.onCreate(savedInstanceState);
        setContentView(R.layout.teacher_signup2);
        Button register,viewb;
      //  viewb=findViewById(R.id.view_teacher);
        register = findViewById(R.id.register);
        Intent intent = getIntent();

        Spinner loc1,loc2,sub1,sub2;
        loc1= findViewById(R.id.s_spinner2);
        loc2= findViewById(R.id.L_spinner2);
        sub1= findViewById(R.id.s_spinner1);
        sub2= findViewById(R.id.spinner2);

        setSpinnerData(loc1,"locations");
        setSpinnerData(loc2,"locations");
        setSpinnerData(sub1,"subjects");
        setSpinnerData(sub2,"subjects");



        register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Bundle b=intent.getExtras();
                String[] datafromTeacher=b.getStringArray("TeacherPage2");


                Boolean checkdata = db.insert_teacher(datafromTeacher[0], datafromTeacher[1], datafromTeacher[3], datafromTeacher[4],datafromTeacher[5]);
                if (checkdata == true) {
                    Toast.makeText(Teacher_SIgnup_Activity2.this, "Data Inserted", Toast.LENGTH_SHORT).show();
                    checkdata = db.insert_login_teacher(datafromTeacher[1], datafromTeacher[2]);
                    db.new_teacher_allocation();
                    if (checkdata) {
                        Toast.makeText(Teacher_SIgnup_Activity2.this, "Login Updated", Toast.LENGTH_SHORT).show();
                        checkdata = db.insert_teacher_location(datafromTeacher[1], loc1.getSelectedItem().toString(), loc2.getSelectedItem().toString());
                        if (checkdata)
                            Toast.makeText(Teacher_SIgnup_Activity2.this, "Location Updated", Toast.LENGTH_SHORT).show();
                        checkdata = db.insert_teacher_subject(datafromTeacher[1], sub1.getSelectedItem().toString(), sub2.getSelectedItem().toString());
                        if (checkdata)
                            Toast.makeText(Teacher_SIgnup_Activity2.this, "Subject Updated", Toast.LENGTH_SHORT).show();


                    }
                }
                else
                    Toast.makeText(Teacher_SIgnup_Activity2.this, "Data not Inserted", Toast.LENGTH_SHORT).show();
            }


        });

//        viewb.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                Cursor res = db.getData();
//                if (res.getCount() == 0) {
//                    Toast.makeText(Teacher_SIgnup_Activity2.this, "No Entry Exists", Toast.LENGTH_SHORT).show();
//                    return;
//                }
//                StringBuffer buffer = new StringBuffer();
//                while (res.moveToNext()) {
//                    buffer.append("Full Name:" + res.getString(0) + "\n");
//                    buffer.append("Email:" + res.getString(2) + "\n");
//                    buffer.append("Password:" + res.getString(3) + "\n");
//                    buffer.append("CNIC:" + res.getString(6) + "\n");
//                    buffer.append("Contact:" + res.getString(8) + "\n");
//
//                }
//                AlertDialog.Builder builder = new AlertDialog.Builder(Teacher_SIgnup_Activity2.this);
//                builder.setCancelable(true);
//                builder.setTitle("Teacher Entries");
//                builder.setMessage(buffer.toString());
//                builder.show();
//            }
//
//        });
    }
    private void setSpinnerData(Spinner spinner, String filename) {
        Vector<String> str=new Vector<String>();
        BufferedReader in = null;
        try {
            in = new BufferedReader(new InputStreamReader(getAssets().open(filename)));
        } catch (IOException e) {
            e.printStackTrace();
        }

        String line = null;
        try {
            line = in.readLine();
        } catch (IOException e) {
            e.printStackTrace();
        }
        int index = 0;
        while (line != null) {

            str.add(line);
            try {
                line = in.readLine();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }

        ArrayAdapter adapter = new ArrayAdapter(getActivity(), android.R.layout.simple_spinner_item, str);

        spinner.setAdapter(adapter);
    }

    public Context getActivity() {
        return this;
    }
}