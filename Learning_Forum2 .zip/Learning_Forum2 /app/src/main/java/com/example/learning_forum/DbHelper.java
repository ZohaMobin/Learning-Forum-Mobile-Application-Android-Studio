package com.example.learning_forum;


import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.os.Build;
import java.util.Date;

import androidx.annotation.RequiresApi;

import java.time.LocalDateTime;
import java.util.concurrent.TimeUnit;

public class DbHelper extends SQLiteOpenHelper {
    private Object LocalDate;

    public DbHelper(Context context) {
        super(context, "Userdata.db", null, 1);
    }

    @Override
    //These are the created tables
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE student_details(Fname TEXT NOT NULL,Lname TEXT NOT NULL,s_email TEXT primary key, age TEXT,contact TEXT default '0300' CONSTRAINT contact CHECK (contact not like '%[^0-9]%') )");
        db.execSQL("CREATE TABLE teacher_details(Fullname TEXT NOT NULL,t_email TEXT primary key,cnic TEXT UNIQUE NOT NULL,contact TEXT CONSTRAINT contact CHECK (contact not like '%[^0-9]%'),board TEXT NOT NULL)");
        db.execSQL("CREATE TABLE student_login(s_email TEXT primary key,s_password TEXT NOT NULL, foreign key (s_email) references student_details(s_email) on delete cascade)");
        db.execSQL("CREATE TABLE teacher_login(t_email TEXT primary key,t_password TEXT NOT NULL, foreign key (t_email) references teacher_details(t_email) on delete cascade)");
        db.execSQL("CREATE TABLE t_location(t_email TEXT primary key,loc1 TEXT NOT NULL, loc2 TEXT ,foreign key (t_email) references teacher_details(t_email) on delete cascade)");
        db.execSQL("CREATE TABLE t_subject(t_email TEXT primary key,sub1 TEXT NOT NULL, sub2 TEXT ,foreign key (t_email) references teacher_details(t_email) on delete cascade)");
        db.execSQL("CREATE TABLE tuition(t_id INT primary key,s_email TEXT NOT NULL,s_loc TEXT NOT NULL,s_sub TEXT NOT NULL,s_board TEXT NOT NULL,status TEXT,foreign key (s_email) references student_details(s_email) on delete cascade)");
        db.execSQL("CREATE TABLE allocated_tuitions(t_id TEXT primary key,s_email TEXT NOT NULL,t_email TEXT NOT NULL,foreign key (s_email) references student_details(s_email) on delete cascade, foreign key (t_id) references tuition(t_id) on delete cascade, foreign key (t_email) references teacher_details(t_email) on delete cascade)");
        db.execSQL("CREATE TABLE tuition_records(t_id TEXT,status TEXT not null,date DATE,primary key(t_id,date), foreign key (t_id) references tuition(t_id) on delete cascade)");

        System.out.println("Creating tables");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int i, int i1) {
        //db.execSQL("DROP TABLE IF EXISTS Userdetails2");
        //db.execSQL("DROP TABLE IF EXISTS teacher_details");

    }

    //Data Insertion
    public Boolean insertdata(String fname, String lname, String email, String age, String contact) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("Fname", fname);
        values.put("Lname", lname);
        values.put("s_email", email);

        values.put("age", age);
        values.put("contact", contact);
        long result = db.insert("student_details", null, values);
        if (result == -1) {
            return false;
        } else {
            return true;
        }

    }

    public Boolean insert_login_student(String email, String password) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("s_email", email);
        values.put("s_password", password);
        long result = db.insert("student_login", null, values);
        if (result == -1) {
            return false;
        } else {
            return true;
        }
    }

    public Boolean insert_teacher_location(String email, String loc1, String loc2) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("t_email", email);
        values.put("loc1", loc1);
        values.put("loc2", loc2);

        long result = db.insert("t_location", null, values);

        if (result == -1) {
            return false;
        } else {
            return true;
        }
    }


    public Boolean insert_login_teacher(String email, String password) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("t_email", email);
        values.put("t_password", password);
        long result = db.insert("teacher_login", null, values);
        if (result == -1) {
            return false;
        } else {
            return true;
        }
    }


    public Boolean insert_teacher(String fname, String email, String cnic, String contact, String board) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("Fullname", fname);
        values.put("t_email", email);
        values.put("cnic", cnic);
        values.put("contact", contact);
        values.put("board", board);
        long result = db.insert("teacher_details", null, values);
        if (result == -1) {
            return false;
        } else {
            return true;
        }

    }


    public Cursor getData() {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("Select * from student_details", null);
        return cursor;
    }

    public Boolean insert_tuition(String email, String Location, String Subject, String Board) {
        //System.out.println("Inserting teacher");
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        int id = checkTID(email);
        values.put("t_id", id + 1);
        values.put("s_email", email);
        values.put("s_loc", Location);
        values.put("s_sub", Subject);
        values.put("s_board", Board);
        values.put("status", "Pending");

        long result = db.insert("tuition", null, values);
        if (result == -1) {
            return false;
        } else {
            insert_tuition_record(id + 1, "Pending");

            String teacher_email = get_teacher(Subject, Board, Location);
            if (teacher_email == null)
                return true;

            Boolean flag = allocate_teacher(email, teacher_email, id + 1);
            return true;
        }

    }

    public Boolean insert_tuition_record(int id, String status) {
        //System.out.println("Inserting teacher");
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        //int id = checkTID(email);
        values.put("t_id", id);
        //values.put("s_email", email);
        values.put("status", status);
        Date d = new Date();
        values.put("date", String.valueOf(d.toString()));

        long result = db.insert("tuition_records", null, values);
        if (result == -1) {
            return false;
        } else {
            return true;
        }
    }

    public void updateStudent(String str, String spin, String email) {

        // calling a method to get writable database.

        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();

        System.out.println(spin);

        if (spin.equals("First Name")) {
          //  System.out.println("Boom");
            values.put("Fname", str);
            db.update("student_details", values, "s_email=?", new String[]{email});
        }
        if (spin.equals("Last Name")) {
         //   System.out.println("Boom");
            values.put("Lname", str);
            db.update("student_details", values, "s_email=?", new String[]{email});
        }
        if (spin.equals("Password")) {
            values.put("s_password", str);
            db.update("student_login", values, "s_email=?", new String[]{email});

        }
        if (spin.equals("Age")) {
            values.put("age", str);
            db.update("student_login", values, "s_email=?", new String[]{email});

        }
        if (spin.equals("Contact")) {
            values.put("contact", str);
            db.update("student_details", values, "s_email=?", new String[]{email});

        }
        // System.out.println("No string matched");

        db.close();
    }

    public String[][] getStudentData(String email) {
        SQLiteDatabase db = this.getReadableDatabase();
        String query = "Select s_sub,s_loc,t_id from tuition where s_email=\'" + email + "\';";
        Cursor res = db.rawQuery(query, null);

        String[][] data = new String[3][4];
        int i = 0;
        while (res.moveToNext() & i < 3) {
            data[i][0] = res.getString(0);
            data[i][1] = res.getString(1);
            i++;
        }
        return data;
    }

    public void new_teacher_allocation()
    {
        String query = " SELECT T.s_sub,T.s_loc,T.s_board,T.s_email,T.t_id\n" +
                " FROM tuition T\n" +
                " WHERE \tT.status=\"Pending\";";
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor res = db.rawQuery(query, null);
        while (res.moveToNext()){
            String subject = res.getString(0);
            String location = res.getString(1);
            String board = res.getString(2);
            String s_email = res.getString(3);
            int t_id = res.getInt(4);
            String t_email = get_teacher(subject,board,location);
            if(t_email!=null)
            {
                allocate_teacher(t_email,s_email,t_id);
                break;
            }
        }
    }

    public String get_teacher(String subject, String board, String location) {
        SQLiteDatabase db = this.getReadableDatabase();
        String query = "SELECT S.sub1,S.sub2,L.loc1,L.loc2,T.board,T.t_email \n" +
                "from t_subject S, t_location L, teacher_details T\n" +
                "where T.t_email=S.t_email and T.t_email=L.t_email;";

        Cursor res = db.rawQuery(query, null);
        while (res.moveToNext()) {
            String sub1 = res.getString(0);
            String sub2 = res.getString(1);
            String loc1 = res.getString(2);
            String loc2 = res.getString(3);
            String bd = res.getString(4);
            String email = res.getString(5);
            System.out.println(email);

            if((sub1.equals(subject) | sub2.equals(subject)) & (location.equals(loc1)|location.equals(loc2)) & board.equals(bd))
                return email;
        }
        return null;
    }

    public Boolean allocate_teacher(String s_email, String t_email, int id) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        //int id = checkTID(email);
        values.put("t_id", id);
        //values.put("s_email", email);
        values.put("s_email", s_email);
        values.put("t_email", t_email);
        System.out.println("Testing 1");
        long result = db.insert("allocated_tuitions", null, values);

        if (result == -1) {
            System.out.println("Testing 2");
            return false;
        } else {
            try {
                TimeUnit.SECONDS.sleep(2);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            UpdateTuition(id,"Allocated");
            insert_tuition_record(id,"Allocated");
            System.out.println("Testing 3");
            return true;
        }

    }

    public void UpdateTuition(int t_id,String status)
    {

        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("status", status);
        db.update("tuition", values, "t_id=?", new String[]{Integer.toString(t_id)});
        db.update("tuition_records", values, "t_id=?", new String[]{Integer.toString(t_id)});

    }

    public String[][] getRequests(String t_email)
    {
        SQLiteDatabase db = this.getReadableDatabase();
        String[][] data = new String[2][5];
        String query = "SELECT  T.s_sub,T.s_loc,T.t_id, S.Fname||\" \"||S.Lname\n, S.contact " +
                "FROM tuition T, allocated_tuitions A, student_details S\n" +
                "WHERE A.t_id=T.t_id AND T.s_email=S.s_email AND A.t_email = \"" + t_email + "\";";
        Cursor res = db.rawQuery(query, null);

        int i = 0;
        while (res.moveToNext() & i < 2) {
            data[i][0] = res.getString(0);
            data[i][1] = res.getString(1);
            data[i][2] = Integer.toString(res.getInt(2));
            data[i][3] = res.getString(3);
            data[i][4] = res.getString(4);
            i++;
        }


        return data;
    }

    public int checkTID(String email) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor res = db.rawQuery("Select * from tuition", null);
        int id = 0;
        while (res.moveToNext()) {
            String val = res.getString(0);
            id = Integer.parseInt(val);
            //System.out.println(val+" "+val2);
        }
        return id;
    }


    //This shows how the data is accessed from database
    public Boolean checkStudentLoginInfo(String email, String password) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor res = db.rawQuery("Select * from student_login", null);

        while (res.moveToNext()) {
            String val = res.getString(0);
            String val2 = res.getString(1);
            //System.out.println(email+" "+password);
            if (email.equals(val) & password.equals(val2))
                return true;
            System.out.println(val + " " + val2);
        }
        return false;
    }

    public Boolean checkTeacherLoginInfo(String email, String password) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor res = db.rawQuery("Select * from teacher_login", null);

        while (res.moveToNext()) {
            String val = res.getString(0);
            String val2 = res.getString(1);
            //System.out.println(email+" "+password);
            if (email.equals(val) & password.equals(val2))
                return true;
            //System.out.println(val+" "+val2);
        }
        return false;
    }

    public Boolean insert_teacher_subject(String email, String sub1, String sub2) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("t_email", email);
        values.put("sub1", sub1);
        values.put("sub2", sub2);

        long result = db.insert("t_subject", null, values);

        if (result == -1) {
            return false;
        } else {
            return true;
        }
    }
//    public void updateCourse(String str,String spin) {
//
//        // calling a method to get writable database.
//        SQLiteDatabase db = this.getWritableDatabase();
//        ContentValues values = new ContentValues();
//
//        if(spin=="Email"){
//            values.put(s_email, str);
//        }
//        if(spin=="Password"){
//            values.put(s_password, str);
//
//        }
//        db.update(student_login, values, "s_password=?", new String[]{s_password});
//        db.close();
//    }

    //}
    public void updateTeacher(String str, String spin, String email) {

        // calling a method to get writable database.

        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();

        System.out.println(spin);
        if (spin.equals("Full Name")) {
            values.put("Fullname", str);
            db.update("teacher_details", values, "t_email=?", new String[]{email});
        }

        if (spin.equals("Password")) {
            values.put("t_password", str);
            db.update("teacher_login", values, "t_email=?", new String[]{email});

        }
        if (spin.equals("Cnic")) {
            values.put("cnic", str);
            db.update("teacher_details", values, "t_email=?", new String[]{email});

        }
        if (spin.equals("Contact")) {
            values.put("contact", str);
            db.update("teacher_details", values, "t_email=?", new String[]{email});

        }
        if (spin.equals("Board")) {
            values.put("board", str);
            db.update("teacher_details", values, "t_email=?", new String[]{email});

        }
        System.out.println("No string matched");

        db.close();
    }
    public void deleteStudent(String email) {

        SQLiteDatabase db = this.getWritableDatabase();
        db.execSQL("PRAGMA foreign_keys = ON;\n");
        db.delete("student_details", "s_email=?", new String[]{email});
        db.close();
    }
    public void deleteTeacher(String email) {

        SQLiteDatabase db = this.getWritableDatabase();
        db.execSQL("PRAGMA foreign_keys = ON;\n");
        db.delete("teacher_details", "t_email=?", new String[]{email});
        db.close();
    }
    public void deleteTuition(int t_id) {

        SQLiteDatabase db = this.getWritableDatabase();
        db.execSQL("PRAGMA foreign_keys = ON;\n");
        db.delete("tuition", "t_id=?", new String[]{Integer.toString(t_id)});
        db.close();
    }


}