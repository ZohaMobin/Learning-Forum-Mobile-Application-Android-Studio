package com.example.learning_forum;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;

import androidx.appcompat.app.AppCompatActivity;

public class Teacher_Dashboard_Activity  extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        DbHelper db = new DbHelper(this);

        super.onCreate(savedInstanceState);
        setContentView(R.layout.teacher_dashboard);
        Intent intent = getIntent();
        String emailTXT= getIntent().getStringExtra("TeacherEmailFromLogin");

        ImageView requests = findViewById(R.id.bus);
        ImageView update = findViewById(R.id.bus1);

        requests.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent2 = new Intent(getApplicationContext(), Teacher_Requests_Activity.class);
                intent2.putExtra("TeacherEmailFromLogin", emailTXT);
                startActivity(intent2);
            }

        });
        update.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent3 = new Intent(getApplicationContext(), Teacher_Update_Activity.class);
                intent3.putExtra("TeacherEmailFromLogin", emailTXT);
                startActivity(intent3);

            }
        });

    }

}