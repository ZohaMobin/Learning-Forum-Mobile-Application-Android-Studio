package com.example.learning_forum;

import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Vector;

public class Tuition_Insert_Activity  extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        DbHelper db = new DbHelper(this);

        //db.createTeacher(db);

        super.onCreate(savedInstanceState);
        setContentView(R.layout.tution);
        Intent intent = getIntent();

        Button register,viewb;
        EditText id_txt = null,status_txt = null;
        Spinner loc,sub,board;
//        EditText email = findViewById(R.id.email_reg);

       // viewb=findViewById(R.id.view_teacher);
        register = findViewById(R.id.register);

        sub= findViewById(R.id.spinner2);
        loc= findViewById(R.id.L_spinner2);
        board= findViewById(R.id.b_spinner);

        setSpinnerData(loc,"locations");
        setSpinnerData(sub,"subjects");
        setSpinnerData(board,"board");

        String emailTXT = getIntent().getStringExtra("StudentEmailFromLogin");

        register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Boolean checkdata = db.insert_tuition(emailTXT,loc.getSelectedItem().toString(),sub.getSelectedItem().toString(),board.getSelectedItem().toString());

                if (checkdata == true)
                    Toast.makeText(Tuition_Insert_Activity.this, "Data Inserted", Toast.LENGTH_SHORT).show();
                else
                    Toast.makeText(Tuition_Insert_Activity.this, "Data not Inserted", Toast.LENGTH_SHORT).show();

            }


        });
//        viewb.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                Cursor res = db.getData();
//                if (res.getCount() == 0) {
//                    Toast.makeText(Tuition_Insert_Activity.this, "No Entry Exists", Toast.LENGTH_SHORT).show();
//                    return;
//                }
//                StringBuffer buffer = new StringBuffer();
//                while (res.moveToNext()) {
//                    buffer.append("Full Name:" + res.getString(0) + "\n");
//                    buffer.append("Email:" + res.getString(1) + "\n");
//                    buffer.append("Password:" + res.getString(2) + "\n");
//                    buffer.append("CNIC:" + res.getString(3) + "\n");
//                    buffer.append("Contact:" + res.getString(4) + "\n");
//
//                }
//                AlertDialog.Builder builder = new AlertDialog.Builder(Tuition_Insert_Activity.this);
//                builder.setCancelable(true);
//                builder.setTitle("Teacher Entries");
//                builder.setMessage(buffer.toString());
//                builder.show();
//            }

     //   });
    }
    private void setSpinnerData(Spinner spinner, String filename) {
        Vector<String> str=new Vector<String>();
        BufferedReader in = null;
        try {
            in = new BufferedReader(new InputStreamReader(getAssets().open(filename)));
        } catch (IOException e) {
            e.printStackTrace();
        }
        String line = null;
        try {
            line = in.readLine();
        } catch (IOException e) {
            e.printStackTrace();
        }
        int index = 0;
        while (line != null) {

            str.add(line);
            try {
                line = in.readLine();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }

        ArrayAdapter adapter = new ArrayAdapter(getActivity(), android.R.layout.simple_spinner_item, str);

        spinner.setAdapter(adapter);
    }

    public Context getActivity() {
        return this;
    }

}
