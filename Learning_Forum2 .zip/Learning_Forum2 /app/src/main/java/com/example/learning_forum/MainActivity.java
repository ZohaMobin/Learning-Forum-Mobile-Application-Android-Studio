package com.example.learning_forum;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
  //  setContentView(R.layout.available_teachers);
       setContentView(R.layout.activity_main);
        Button studentB,teacherB;
        DbHelper db;
        db = new DbHelper(this);
        studentB = findViewById(R.id.push_button);
        teacherB = findViewById(R.id.push_button2);
        db.deleteStudent("muz");
//        db.deleteTuition(1);
        studentB.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String value="Teacher";
                LoginPage(view,value);
            }
        });
        teacherB.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String value="Student";
                LoginPage(view, value);
            }
       });
  }



    public void LoginPage(View v, String value){
        //Toast.makeText(this, "We next page", Toast.LENGTH_SHORT).show();

        Intent intent = new Intent(this,Login_Page_Activity.class);
        intent.putExtra("UserType",value);
        startActivity(intent);
    }

}