package com.example.learning_forum;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class Student_Update_Activity extends AppCompatActivity {


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        DbHelper db = new DbHelper(this);
        EditText up_data;
        //db.createTeacher(db);

        super.onCreate(savedInstanceState);
        setContentView(R.layout.student_update_page);
        ImageButton edit;
        Spinner up_spin;
        edit = (ImageButton) findViewById(R.id.imageButton3);
        up_spin= findViewById(R.id.spinner);

        up_data = findViewById(R.id.data);
        Intent intent = getIntent();
        String emailTXT = getIntent().getStringExtra("StudentEmailFromLogin");

        edit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String datatxt = up_data.getText().toString();
                db.updateStudent(datatxt,up_spin.getSelectedItem().toString(),emailTXT);

                // displaying a toast message that our course has been updated.
                Toast.makeText(Student_Update_Activity.this, "Course Updated..", Toast.LENGTH_SHORT).show();

                // launching our main activity.
                //    Intent i = new Intent(Update_Activity.this, MainActivity.class);
                //  startActivity(i);

                //  Bundle b = intent.getExtras();



                //Boolean checkdata = db.update_student(editstudent[0], editstudent[1], editstudent[2], editstudent[3], editstudent[4],editstudent[5]);
//                if (checkdata == true)
//                    Toast.makeText(Update_Activity.this, "Data Updated", Toast.LENGTH_SHORT).show();
//                else
//                    Toast.makeText(Update_Activity.this, "Data not Updated", Toast.LENGTH_SHORT).show();

            }


        });
    }

}