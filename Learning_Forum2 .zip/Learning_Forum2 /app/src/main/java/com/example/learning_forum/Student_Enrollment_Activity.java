package com.example.learning_forum;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

public class Student_Enrollment_Activity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {

        DbHelper db = new DbHelper(this);

        Intent intent = getIntent();
        String emailTXT = getIntent().getStringExtra("StudentEmailFromLogin");

        super.onCreate(savedInstanceState);
        setContentView(R.layout.student_enrollment);

        String[][] data  = db.getStudentData(emailTXT);
        if (data[0][0].equals("")) {
            Toast.makeText(Student_Enrollment_Activity.this, "No Entry Exists", Toast.LENGTH_SHORT).show();
            return;
        }
        TextView sub1 = findViewById(R.id.textView20);
        sub1.setText(data[0][0]);
        TextView loc1 = findViewById(R.id.textView21);
        loc1.setText(data[0][1]);

        LinearLayout l2 = findViewById(R.id.linearLayout2);
        l2.setVisibility(View.INVISIBLE);

        LinearLayout l3 = findViewById(R.id.Linear_layout3);
        l3.setVisibility(View.INVISIBLE);

//        StringBuffer buffer = new StringBuffer();

//        buffer.append("Subject" + data[0] + "\n");
//        buffer.append("Location:" + data[1] + "\n");

//           buffer.append("Teacher Name:" + res.getString(2) + "\n");
//            buffer.append("Date" + res.getString(3) + "\n");
//        AlertDialog.Builder builder = new AlertDialog.Builder(Student_Enrollment_Activity.this);
//        builder.setCancelable(true);
//        builder.setTitle("User Entries");
//        builder.setMessage(buffer.toString());
//        builder.show();
    }





}