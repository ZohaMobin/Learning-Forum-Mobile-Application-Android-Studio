package com.example.learning_forum;

import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
        import java.util.Vector;

public class Teacher_Requests_Activity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        DbHelper db = new DbHelper(this);

        super.onCreate(savedInstanceState);
        setContentView(R.layout.teacher_requests);
        Intent intent = getIntent();
        String email= getIntent().getStringExtra("TeacherEmailFromLogin");

        String data[][]=db.getRequests(email);
        if (data[0][0]==null) {
            Toast.makeText(Teacher_Requests_Activity.this, "No Entry Exists", Toast.LENGTH_SHORT).show();
//            return;
        }
        TextView sub1 = findViewById(R.id.subject1);
        sub1.setText(data[0][0]);
        TextView loc1 = findViewById(R.id.location1);
        loc1.setText(data[0][1]);
        TextView id = findViewById(R.id.id1);
        id.setText(data[0][2]);
        TextView sname = findViewById(R.id.teacher1);
        sname.setText(data[0][3]);
        System.out.println(data[0][3]);
        
        LinearLayout l2 = findViewById(R.id.linearLayout2);
        l2.setVisibility(View.INVISIBLE);

        LinearLayout l3 = findViewById(R.id.Linear_layout3);
        l3.setVisibility(View.INVISIBLE);

        TextView contact = findViewById(R.id.contact);
        contact.setText(data[0][4]);
        contact.setVisibility(View.INVISIBLE);
        CheckBox tick = findViewById(R.id.checkBox4);
        tick.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                System.out.println("Testing check box");
                contact.setVisibility(View.VISIBLE);
                db.UpdateTuition(Integer.parseInt(data[0][2]),"Confirmed");
                System.out.println(data[0][4]);

                //db.insert_tuition_record(Integer.parseInt(data[0][2]),"Confirmed");

            }
        });

    }
}