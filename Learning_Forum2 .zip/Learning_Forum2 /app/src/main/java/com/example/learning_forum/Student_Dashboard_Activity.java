package com.example.learning_forum;

import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Vector;

public class Student_Dashboard_Activity  extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        DbHelper db = new DbHelper(this);

        super.onCreate(savedInstanceState);
        setContentView(R.layout.student_dashboard);
        Intent intent = getIntent();
        Bundle extras = getIntent().getExtras();
        String emailTXT = "";
        if (extras != null) {
            emailTXT = extras.getString("StudentEmailFromLogin");
        }
        ImageView find_tutor = findViewById(R.id.train);
        ImageView enrollment = findViewById(R.id.cycle);
        ImageView update = findViewById(R.id.bus1);

        String finalEmailTXT = emailTXT;
        find_tutor.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent2 = new Intent(getApplicationContext(),Tuition_Insert_Activity.class);
                intent2.putExtra("StudentEmailFromLogin", finalEmailTXT);
                startActivity(intent2);
            }
        });
        enrollment.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent3 = new Intent(getApplicationContext(),Student_Enrollment_Activity.class);
                intent3.putExtra("StudentEmailFromLogin", finalEmailTXT);
                startActivity(intent3);

            }
        });
        update.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent4 = new Intent(getApplicationContext(),Student_Update_Activity.class);
                intent4.putExtra("StudentEmailFromLogin", finalEmailTXT);
                startActivity(intent4);

            }
        });
    }


}


