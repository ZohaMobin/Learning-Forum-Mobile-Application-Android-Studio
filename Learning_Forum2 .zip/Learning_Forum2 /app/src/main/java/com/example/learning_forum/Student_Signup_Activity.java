package com.example.learning_forum;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class Student_Signup_Activity extends AppCompatActivity {

    EditText Fname;
    EditText Lname;
    EditText email;
    EditText age;
    EditText board;
    EditText grade;
    EditText pass;
    EditText Location;
    EditText contact;
    Button insert,view;
    DbHelper db;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // setContentView(R.layout.activity_main);
        setContentView(R.layout.new_userlogin);
        Intent intent = getIntent();
        //setContentView(R.layout.teacher_reg);
        Fname = findViewById(R.id.Fname);
        Lname = findViewById(R.id.Lname);
        email = findViewById(R.id.email_reg);
        pass = findViewById(R.id.pass);
        age = findViewById(R.id.age);
        contact = findViewById(R.id.contact);

        insert = findViewById(R.id.submit);
        view = findViewById((R.id.loginView));

        db = new DbHelper(this);
        insert.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String FnameTXT = Fname.getText().toString();
                String LnameTXT = Lname.getText().toString();
                String emailTXT = email.getText().toString();
                String passTXT = pass.getText().toString();
                String ageTXT = age.getText().toString();
                String contactTXT = contact.getText().toString();
                Boolean flag=check_null(FnameTXT,LnameTXT,emailTXT,passTXT,ageTXT,contactTXT);

                System.out.println("testing 1");
                if(flag==false){
                    Toast.makeText(Student_Signup_Activity.this, "Invalid Data", Toast.LENGTH_SHORT).show();
                    Intent intent = new Intent(getApplicationContext(), Student_Signup_Activity.class);
                    startActivity(intent);
                }
                System.out.println("testing 2");
                Boolean checkdata = db.insertdata(FnameTXT, LnameTXT, emailTXT, ageTXT, contactTXT);
                if (checkdata == true) {
                    System.out.println("testing 3");
                    Toast.makeText(Student_Signup_Activity.this, "Data Inserted", Toast.LENGTH_SHORT).show();
                    checkdata = db.insert_login_student(emailTXT, passTXT);
                    if (checkdata)
                        Toast.makeText(Student_Signup_Activity.this, "Login Updated", Toast.LENGTH_SHORT).show();
                    else
                        Toast.makeText(Student_Signup_Activity.this, "Login Not Updated", Toast.LENGTH_SHORT).show();
                    Intent intent = new Intent(getApplicationContext(), Student_Dashboard_Activity.class);
                    intent.putExtra("StudentEmailFromLogin",emailTXT);
                    startActivity(intent);

                } else
                    Toast.makeText(Student_Signup_Activity.this, "Data not Inserted", Toast.LENGTH_SHORT).show();


            }
        });

        view.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Cursor res = db.getData();
                if (res.getCount() == 0) {
                    Toast.makeText(Student_Signup_Activity.this, "No Entry Exists", Toast.LENGTH_SHORT).show();
                    return;
                }
                StringBuffer buffer = new StringBuffer();
                while (res.moveToNext()) {
                    buffer.append("First Name:" + res.getString(0) + "\n");
                    buffer.append("Last Name:" + res.getString(1) + "\n");
                    buffer.append("Email:" + res.getString(2) + "\n");
                    buffer.append("Age:" + res.getString(3) + "\n");
                    buffer.append("Contact:" + res.getString(4) + "\n");

                }
                AlertDialog.Builder builder = new AlertDialog.Builder(Student_Signup_Activity.this);
                builder.setCancelable(true);
                builder.setTitle("User Entries");
                builder.setMessage(buffer.toString());
                builder.show();
            }

        });
    }
        public boolean check_null(String fn,String ln,String email,String pass,String age,String contact)
        {
            if(fn=="" | ln=="" | email=="" | pass=="" | age=="" | contact=="")
                return false;
            return true;
        }

}