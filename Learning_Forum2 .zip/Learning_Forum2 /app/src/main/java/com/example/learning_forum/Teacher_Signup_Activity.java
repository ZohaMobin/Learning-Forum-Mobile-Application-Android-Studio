package com.example.learning_forum;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Spinner;

public class Teacher_Signup_Activity extends AppCompatActivity {


    DbHelper db;
    Button next;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.teacher_reg);
        //setContentView(R.layout.teacher_reg2);
        //  next = findViewById(R.id.nextpage);

        // setContentView(R.layout.new_userlogin);
        //  student_signup();
        teacher_signup();

    }
    public void teacher_signup()
    {
        EditText Fullname;
        EditText email;
        EditText cnic;
        EditText pass;
        EditText contact;
        Spinner board,loc1,loc2,sub1,sub2;
        Button pop;
        ImageView reg_teacher;



        Fullname = findViewById(R.id.Fullname);
        email = findViewById(R.id.email_reg);
        pass = findViewById(R.id.pass);
        contact = findViewById(R.id.contact);
        cnic = findViewById(R.id.cnic);
        board=findViewById(R.id.spinner_board);
        loc1=findViewById(R.id.L_spinner1);
        loc2=findViewById(R.id.L_spinner2);
        sub1=findViewById(R.id.s_spinner1);
        sub2=findViewById(R.id.spinner2);



        reg_teacher = (ImageView) findViewById(R.id.teacher_reg1);

        db = new DbHelper(this);
        reg_teacher.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v)
            {
                String nameTXT = Fullname.getText().toString();
                String emailTXT = email.getText().toString();
                String passTXT = pass.getText().toString();
                String cnicTXT = cnic.getText().toString();
                String contactTXT = contact.getText().toString();
                //loadSpinnerData();
                String boardTXT= board.getSelectedItem().toString();
                String[] datatoPass= {nameTXT,emailTXT,passTXT,cnicTXT,contactTXT,boardTXT};

                Bundle b=new Bundle();
                b.putStringArray("TeacherPage2",datatoPass);

                Intent i=new Intent(getApplicationContext(),Teacher_SIgnup_Activity2.class);
                i.putExtras(b);
                System.out.println("Testing");
                startActivity(i);
            }
        });

//        view.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                Cursor res = db.getData();
//                if (res.getCount() == 0) {
//                    Toast.makeText(Teacher_Signup_Activity.this, "No Entry Exists", Toast.LENGTH_SHORT).show();
//                    return;
//                }
//                StringBuffer buffer = new StringBuffer();
//                while (res.moveToNext()) {
//                    buffer.append("Full Name:" + res.getString(0) + "\n");
//                    buffer.append("Email:" + res.getString(2) + "\n");
//                    buffer.append("Password:" + res.getString(3) + "\n");
//                    buffer.append("CNIC:" + res.getString(6) + "\n");
//                    buffer.append("Contact:" + res.getString(8) + "\n");
//
//                }
//                AlertDialog.Builder builder = new AlertDialog.Builder(Teacher_Signup_Activity.this);
//                builder.setCancelable(true);
//                builder.setTitle("Teacher Entries");
//                builder.setMessage(buffer.toString());
//                builder.show();
//            }

//        });

    }
//    private void loadSpinnerData() {
//        // database handler
//        Spinner board;
//        board=findViewById(R.id.spinner_board);
//
//        DbHelper db=new DbHelper(getApplicationContext());
//
//        ArrayAdapter<String> dataAdapter = new ArrayAdapter<String>(this,
//                android.R.layout.simple_spinner_item);
//        dataAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
//        board.setAdapter(dataAdapter);
//    }

}